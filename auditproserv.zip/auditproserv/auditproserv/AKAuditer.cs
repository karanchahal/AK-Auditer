﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using System.Threading;
using System.Runtime.InteropServices;
using System.Configuration;
using System.Net;
using System.Net.Sockets;

namespace auditproserv
{
    public partial class AKAuditer : ServiceBase
    {
        //[DllImport("C:\\Users\\Aditya\\Documents\\Visual Studio 2013\\Projects\\auditprodll\\Debug\\auditprodll.dll", CallingConvention = CallingConvention.Cdecl)]
        [DllImport("D:\\AuditPro\\auditprodll.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int runner();

        public AKAuditer()
        {
            InitializeComponent();
        }
        Thread Worker;
        AutoResetEvent StopRequest = new AutoResetEvent(false);
        int frequency;

        protected override void OnStart(string[] args)
        {

            var appSettings = ConfigurationManager.AppSettings;
            frequency = int.Parse(appSettings["Frequency"]);               
            
            Worker = new Thread(DoWork);
            Worker.Start();

        }

        protected override void OnStop()
        {
        }
        private void SendData()
        {
            try
            {
                TcpClient tcpclnt = new TcpClient();
                Console.WriteLine("Connecting...");

                var appSettings = ConfigurationManager.AppSettings;
                tcpclnt.Connect(appSettings["IP"], int.Parse(appSettings["Port"]));

                Console.WriteLine("Connected...");

                Stream stm = tcpclnt.GetStream();
                ASCIIEncoding asen = new ASCIIEncoding();

                using (StreamReader sr = new StreamReader("D:/AuditPro/usboutput.txt"))
                {
                    String line;
                    Console.WriteLine("Sending...");
                    while ((line = sr.ReadLine()) != null)
                    {
                        byte[] ba = asen.GetBytes(line);

                        stm.Write(ba, 0, ba.Length);
                    }
                }

                tcpclnt.Close();

                //Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error! " + e.StackTrace);
               // Console.ReadKey();
            }
        }
        private void DoWork(object arg)
        {
            // Worker thread loop
            for (; ; )
            {
                // Run this code once every 10 seconds or stop right away if the service is stopped
                if (StopRequest.WaitOne(frequency*60000)) return;
                // Do work...
                //NativeMethods.runner();
                runner();
                SendData();
                //...
            }
        }

/*        internal static class NativeMethods
        {
            [DllImport("C:\\Users\\Aditya\\Documents\\Visual Studio 2013\\Projects\\auditprodll\\Debug\\auditprodll.dll", CallingConvention = CallingConvention.Cdecl)]
            //[DllImport("D:\\AuditPro\\auditprodll.dll", CallingConvention = CallingConvention.Cdecl)]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern int runner();
        }
        */
    }
}
