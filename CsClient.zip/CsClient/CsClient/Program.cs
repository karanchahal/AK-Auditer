﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Configuration;

namespace CsClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                TcpClient tcpclnt = new TcpClient();
                Console.WriteLine("Connecting...");

                var appSettings = ConfigurationManager.AppSettings;
                tcpclnt.Connect(appSettings["IP"], int.Parse(appSettings["Port"]));

                Console.WriteLine("Connected...");

                Stream stm = tcpclnt.GetStream();
                ASCIIEncoding asen = new ASCIIEncoding();


     //           Console.Write("Enter the string to be sent: ");
                using (StreamReader sr = new StreamReader("D:/AuditPro/usboutput.txt"))
                {
                    String line;
                    Console.WriteLine("Sending...");
                    while ((line = sr.ReadLine()) != null)
                    {
//                        String str = Console.ReadLine();
                        //                      byte[] ba = asen.GetBytes(str);
                        byte[] ba = asen.GetBytes(line);

                        stm.Write(ba, 0, ba.Length);
                        /*
                        byte[] bb = new byte[100];
                        int k = stm.Read(bb, 0, 100);

                        for (int i = 0; i < k; i++)
                        {
                            Console.Write(Convert.ToChar(bb[i]));
                        }
                         */

                    }
                }

                tcpclnt.Close();

                Console.ReadKey();
            }
            catch(Exception e)
            {
                Console.WriteLine("Error! " + e.StackTrace);
                Console.ReadKey();
            }

        }
    }
}
