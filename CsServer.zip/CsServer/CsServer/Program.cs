﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Configuration;

namespace CsServer
{
    class Program
    {
        static void Main(string[] args)
        {
            try 
            {
                var appSettings = ConfigurationManager.AppSettings;

                IPAddress ipAddress = IPAddress.Parse(appSettings["IP"]);
                TcpListener myList = new TcpListener(ipAddress, int.Parse(appSettings["Port"]));

                myList.Start();

                Console.WriteLine("Server running - Port: 8000");
                Console.WriteLine("Local end point:" + myList.LocalEndpoint);
                while(true)
                {
                    Console.WriteLine("Waiting for connections...");

                    Socket s = myList.AcceptSocket();

                    Console.WriteLine("Connection accepted from " + s.RemoteEndPoint);

                    int k = 1;

                    StreamWriter sw = new StreamWriter("D:/AuditPro/usbdata.txt");
                    while (k != 0)
                    {
                        byte[] b = new byte[100];
                        k = s.Receive(b);

                        //Console.WriteLine("Received..." );

                        for (int i = 0; i < k; i++)
                        {
                            sw.Write(Convert.ToChar(b[i]));
                        }
                    }

                    sw.Close();
                    //                ASCIIEncoding asen = new ASCIIEncoding();


                    //s.Send(asen.GetBytes("Automatic Message:" + "String Received by server"));
                    //Console.WriteLine("\n Automatic message sent!");

                    s.Close();
                }

                myList.Stop();

                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error..." + e.StackTrace);
                Console.ReadKey();
            }

            
        }
    }
}
