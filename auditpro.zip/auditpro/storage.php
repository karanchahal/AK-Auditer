<!DOCTYPE html>
<html lang="en">
<head>
	<title>Audit-Pro</title>
	<meta charset="utf-8">
	<meta name="author" content="pixelhint.com">
	<meta name="description" content="A secure state logging system"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</head>
<body>

	<header>
		<div class="logo">
			<a href="index.html"><img src="img/logo.png" title="Audit-Pro" alt="Magnetic"/></a>
		</div><!-- end logo -->

		<div id="menu_icon"></div>
		<nav>
			<ul>
			   <li><form>
				<li><a href="index.php" class="selected">Admin Panel</a></li>
				<li><a href="storage.php">Storage</a></li>
				<li><a href="systeminfo.php">System Information</a></li>
				<li><a href="alerts.php">Alerts</a></li>
				<li><a href="contact.html">Contact Us</a></li>
			</ul>
		</nav><!-- end navigation menu -->

		
	</header><!-- end header -->

	<section class="main clearfix">
		<html lang="en">
<head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
  <title></title>
          
<link href="http://fonts.googleapis.com/css?family=Montserrat:300,400,700" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Muli:300,400" rel="stylesheet" type="text/css">

<!--   CSS for 147 Colors   -->
<link href="http://docs.justinav.info/cfbc.css" rel="stylesheet" type="text/css"> 
    
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

  
          
<!--    color palettes       -->
  <center style="
    height: 600px;
">
  <table class="bordered">
    <thead>

    <tr>
        <th>Device Name</th>        
        <th>Description</th>
        <th>Device Type</th>
		<th>Created Date</th>
		<th>Last Plug/Unplug Date</th>
    </tr>
    </thead>
   
    



  
  
   <?php
require_once'core/init.php';

$user = new User();

if(!$user->isLoggedIn())
{
	Redirect::to('login.php');
}

$user2 = new User();


$session=new Session();
 
if(!$session->exists('date')){
			echo '<center>Please Enter date</center>';
		}else{


	    $user->find('storage',$session->get('date'),'Date');
		$x =0;
		$n =10;
		
		if(count($user->data()) == 1 && empty($user->data()->Device_Name)){
			echo '<h2>No records for this date</h2>';
		}else{
			if(count($user->data()) == 1){
				echo '<tr>
			<td>'.$user->data()->Device_Name.'</td>        
			<td>'.$user->data()->Description.'</td>
			<td>'.$user->data()->Device_Type.'</td>
			<td>'.$user->data()->Created_Date.'</td>
			<td>'.$user->data()->Last_Plug_Unplug_Date.'</td>
			</tr>      ';
			}else{
        foreach($user->data() as $results)
        {
	     if($x<$n){
			echo '<tr>
			<td>'.$results->Device_Name.'</td>        
			<td>'.$results->Description.'</td>

			<td>'.$results->Device_Type.'</td>
			<td>'.$results->Created_Date.'</td>
			<td>'.$results->Last_Plug_Unplug_Date.'</td>
			</tr>      ';
	       $x++;
		 }
		}
			}
		}

	  
		}
	  
   
	

?>
   
   
   
   
   
   
   
   </table>
   
  

  
  
	</section><!-- end main -->
	
</body>
</html>