<?php
require('core/init.php');
$user = new User();
if(Session::exists('home')){
	 echo '<p>'.Session::flash('home').'</p>';
 }
 

if($user->isLoggedIn()) {
	Redirect::to('index.php');
	
}
$x =0;
if(Input::exists()){
	if(Token::check(Input::get('token'))) {
		$validate = new Validate();
		$validation = $validate->check($_POST,array(
		'username'=> array('required' =>true),
		'password'=> array('required' =>true)
		));
		
		if($validation->passed()) {
			
			
			
			$login = $user->login(Input::get('username'), Input::get('password'));
			
			
			if($login) {
				Redirect::to('parser.php');
			}else {
		        
				$x =1;
			}
		} else {
			foreach($validation->errors() as $error) {
				echo $error, '<br>';
			}
		}
	}
}




?>






<!DOCTYPE html>




<html >
  <head>
    <meta charset="UTF-8">
    <title>Login</title>
    
    
    
    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  </head>

  <body>

    <body class="align">

  <div class="site__container">

    <div class="grid__container">

      <form action="" method="post" class="form form--login">

        <div class="form__field">
          <label class="fontawesome-user" for="login__username"><span class="hidden">Username</span></label>
          <input id="login__username" type="text" class="form__input" placeholder="Username" required name="username">
        </div>

        <div class="form__field">
          <label class="fontawesome-lock" for="login__password"><span class="hidden">Password</span></label>
          <input id="login__password" type="password" class="form__input" placeholder="Password" required name = "password">
        </div>

        <div class="form__field">
		<input type="hidden" name="token" value="<?php echo Token::generate();?>">
		<?phpif($x =1){ echo 'Please Try Again'}?>
		<input type="submit" value="Sign In"> 
        </div>

      </form>

      

    </div>

  </div>

</body>
    
    
    
    
    
  </body>
</html>
