<?php
//This is the included core file that allows us to use the list of 
//predefined functions in the class folder

require('core/init.php');
  
//this takes in all the contents of the file usb.txt into a string
$storage_info = file_get_contents('C:\AuditPro\usbdata.txt');
$system_info = file_get_contents('systeminfo.txt');


//We're establishing connection with the database here
$db = DB::getInstance();

$result = array();//array declared

$array = explode('^',$storage_info);

//array made out of the string just taken in
//Parsing function,this arranges the contents into a key value pair 
//with the key being the header
//and the value being the value of that header

$x =0;
foreach($array as $array)
{
	$array = explode('!',$array);
	foreach($array as $array)
	{
	     list($name,$value) = explode(':',$array);
		 $result[$name] = $value;
		 
		 
	}
	
	//put in data
	//Here we're inserting the data into the table
	
	$user = new User();
	if($user->find('system_info',$result['MacIDs '],'MacIDs')){

	if(!($user->data()->Product_ID == $result['ProductID'] && $user->data()->Firmware_Revision == $result['Firmware Revision '] && $user->data()->USB_Protocol == $result['USB Protocol']))
	{
		$cookie =new Cookie;
		$cookie->put('alert','CRITICAL ALERT! EQUIPMENT TAMPERED WITH ON COMPUTER WITH MACID: '.$result['MacIDs '].' AND FIRMWARE REVISION: '.$result['Firmware Revision ']);
	    
	}
	}
	try{
	if($x ==0)
	{		
        //inserting header data into the headers table
	    $db->insert('headers',array(
	        
		    'MacIDS'            => $result['MacIDs '],
		    'Username'          => $result['Username '],
		    'Data_Type'         => $result['Data Type ']
		));	
		$x = 1;
    }
    
	$db->insert('storage',array( 
        'MacIDs'            => $result['MacIDs '],
        'Date'         => $result['Date/Time '],		//inserting data into the storage devices section
	    'Device_Name'       => $result['Device Name'],
        'Description'       => $result['Description'],
        'Device_Type'       => $result['Device Type'],
        'Connected'         => $result['Connected'],
        'Safe_To_Unplug'    => $result['Safe To Unplug'],
        'Disabled'          => $result['Disabled'],
        'USB_Hub'           => $result['USB Hub'],
        'Drive_Letter'      => $result['Drive Letter'],
        'Serial_Number'     => $result['Serial Number'],
        'Created_Date'      => $result['Created Date'],
        'Last_Plug_Unplug_Date'=>$result['Last Plug/Unplug Date'],
        'VendorID'          => $result['VendorID'],
        'ProductID'         =>$result['ProductID'],
        'Firmware_Revision' => $result['Firmware Revision '],
        'USB_Class'         => $result['USB Class'],
        'USB_SubClass'      => $result['USB SubClass'],
        'USB_Protocol'      => $result['USB Protocol'],
        'Hub_Port'        => $result['Hub / Port'],
        'Computer_Name'     => $result['Computer Name'],
        'Vendor_Name'       => $result['Vendor Name'],
        'Product_Name'      => $result['Product Name'],
        'ParentId_Prefix'   => $result['ParentId Prefix'],
        'Service_Name'      => $result['Service Name'],
        'Service_Description'=> $result['Service Description'],
        'Driver_Filename'   => $result['Driver Filename'],
        'Device_Class'      => $result['Device Class'],
        'Device_Mfg'        => $result['Device Mfg'],
        'Power'             => $result['Power'],
        'USB_Version'       => $result['USB Version'],
        'Driver_Description'=> $result['Driver Description'],
        'Driver_Version'    => $result['Driver Version'],
        'Instance_ID'       => $result['Instance ID'],
        'Capabilities'      => $result['Capabilities']
		
	));
	
	}catch(Exception $e)
	{
		echo 'A problem has occurred'; //Error Mechanism.Will be updated 
	}
	
}

$array = explode('^',$system_info);
$result = array();

$x =0;
foreach($array as $array)
{
	$array = explode('!',$array);
	foreach($array as $array)
	{
	     list($name,$value) = explode('~',$array);
		 $result[$name] = $value;
		 
		 
	}
	
	//put in data
	//Here we're inserting the data into the table
	try{
	if($x ==0)
	{		
        //inserting header data into the headers table
	    $db->insert('headers',array(
	        
		    'MacIDS'            => $result['MacIDs '],
		    'Username'          => $result['Username '],
		    'Data_Type'         => $result['Data Type ']
		));	
		$x = 1;
    }

	$db->insert('system_info',array( 
        'MacIDs'            => $result['MacIDs '],
        'Date'         => $result['Date'],		//inserting data into the storage devices section
	    'Host_Name'       => $result['Host Name'],
        'OS_Name'       => $result['OS Name'],
        'OS_Version'       => $result['OS Version'],
        'OS_Manufacturer'         => $result['OS Manufacturer'],
        'OS_Configuration'    => $result['OS Configuration'],
        'OS_Build_Type'          => $result['OS Build Type'],
        'Registered_Owner'           => $result['Registered Owner'],
        'Registered_Organization'      => $result['Registered Organization'],
        'Product_ID'     => $result['Product ID'],
        'Original_Install_Date'      => $result['Original Install Date'],
        'System_Boot_Time'=>$result['System Boot Time'],
        'System_Manufacturer'          => $result[ 'System Manufacturer' ],
        'System_Model'         =>$result['System Model'],
        'System_Type' => $result['System Type'],
        'Processor'         => $result['Processor(s)'],
        'Processor_Name'      => $result['Processor Name'],
        'BIOS_Version'      => $result['BIOS Version'],
        'Windows_Directory'        => $result['Windows Directory'],
        'System_Directory'     => $result['System Directory'],
        'Boot_Device'       => $result['Boot Device'],
        'System_Locale'      => $result['System Locale'],
        'Input_Locale'   => $result['Input Locale'],
        'Time_Zone'      => $result['Time Zone'],
        'Total_Physical_Memory'=> $result['Total Physical Memory'],
        'Available_Physical_Memory'   => $result['Available Physical Memory'],
        'Virtual_Memory_Max_Size'      => $result['Virtual Memory Max Size'],
        'Virtual_Memory_Available'        => $result['Virtual Memory Available'],
        'Virtual_Memory_In_Use'             => $result['Virtual Memory In Use'],
        'Page_File_Location'       => $result['Page File Location(s)'],
        'Domain'=> $result['Domain'],
        'Logon_Server'    => $result['Logon Server'],
        'Network_Card'       => $result['Network Card(s)']        
				
	));
	
	}catch(Exception $e)
	{
		echo 'A problem has occurred'; //Error Mechanism.Will be updated 
	}
	
}
Redirect::to('index.php');




?>