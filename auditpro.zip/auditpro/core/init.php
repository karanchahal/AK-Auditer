<?php
session_start();

$GLOBALS['config'] = array(
   'mysql' => array(
   'host' =>'localhost',
   'username' => 'root',
   'password' => '',
   'db' =>'drdo'
 ),
 'session' => array(
 'session_name' => 'user',
 'token_name' =>'token'
)
);

function escape($string){
	return htmlentities($string,ENT_QUOTES,'UTF-8');
}

spl_autoload_register(function($class){
	require_once 'classes/'.$class.'.php';

  });



?>