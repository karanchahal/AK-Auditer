<?php
require_once 'core/init.php';
if(Input::exists()){
	if(Token::check(Input::get('token'))) {
	$validate =new Validate();
	$validation =$validate->check($_POST,array(
	'username'=>array(
	'required' => true,
	'min'=> 2,
	'max' =>20,
	'unique' =>'user'
	),
	'password' => array(
	'required' => true,
	'min' => 6
	),
	'password_again' => array(
	'required' => true,
	'matches' => 'password'
	)
	));
	
	if($validation->passed()){
		$user = new User();
		$pass=Input::get('password');
		try{
			$user->create('user',array(
			'username' => Input::get('username'),
			'password' => Hash::make($pass)
			));
			Session::flash('home','You have been registered.');
			Redirect::to('index.php');
		}catch(Exception $e) {
			die($e->getMessage());
		}
	}
	else
	{
		foreach($validation->errors() as $error) {
			echo $error,'<br>';
		}
	}
	}
}

?>
<form action="" method ="post">
<div class="field">
<label for = "username">Username</label>
<input type = "text" name="username" id="username" value="" autocomplete="off">
</div>
<div class="field">
<label for = "password">Choose a password</label>
<input type = "password" name="password" id="password">
</div>

<div class="field">
<label for = "password_again">Confirm password</label>
<input type = "password" name="password_again" id="password_again">
</div>

<div class="field">
<label for = "name">Name</label>
<input type = "text" name="name" id="name">
</div>
<input type="hidden" name="token" value="<?php echo Token::generate();?>">
<input type="submit" value="Submit">
</form>