<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
echo 'Connected successfully';

$sql = 'CREATE Database drdo';
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create database: ' . mysql_error());
}
echo "Database drdo created successfully\n";



$sql = 'CREATE TABLE `storage` (
 `MacIDs` varchar(100) NOT NULL,
 `Device_Name` varchar(100) NOT NULL,
 `Description` text NOT NULL,
 `Device_Type` text NOT NULL,
 `Connected` varchar(5) NOT NULL,
 `Safe_To_Unplug` varchar(5) NOT NULL,
 `Disabled` varchar(5) NOT NULL,
 `USB_Hub` varchar(5) NOT NULL,
 `Drive_Letter` varchar(5) NOT NULL,
 `Serial_Number` varchar(100) NOT NULL,
 `Created_Date` varchar(100) NOT NULL,
 `Last_Plug_Unplug_Date` varchar(100) NOT NULL,
 `VendorID` varchar(100) NOT NULL,
 `ProductID` varchar(100) NOT NULL,
 `Firmware_Revision` varchar(100) NOT NULL,
 `USB_Class` varchar(100) NOT NULL,
 `USB_SubClass` varchar(100) NOT NULL,
 `USB_Protocol` varchar(100) NOT NULL,
 `Hub_Port` varchar(100) NOT NULL,
 `Computer_Name` varchar(100) NOT NULL,
 `Vendor_Name` varchar(100) NOT NULL,
 `Product_Name` varchar(100) NOT NULL,
 `ParentId_Prefix` varchar(100) NOT NULL,
 `Service_Name` varchar(100) NOT NULL,
 `Service_Description` varchar(100) NOT NULL,
 `Driver_Filename` varchar(100) NOT NULL,
 `Device_Class` varchar(100) NOT NULL,
 `Device_Mfg` varchar(100) NOT NULL,
 `Power` varchar(100) NOT NULL,
 `USB_Version` varchar(100) NOT NULL,
 `Driver_Description` varchar(100) NOT NULL,
 `Driver_Version` varchar(100) NOT NULL,
 `Instance_ID` varchar(200) NOT NULL,
 `Capabilities` varchar(200) NOT NULL,
 `id` int(15) NOT NULL AUTO_INCREMENT,
 `Date` date NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `id` (`id`),
 UNIQUE KEY `unique_index` (`Device_Name`,`Date`,`Instance_ID`),
 KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=latin1';

mysql_select_db('drdo');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create table: ' . mysql_error());
}
echo "Table employee created successfully\n";


$sql = 'CREATE TABLE `system_info` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `Host_Name` varchar(200) NOT NULL,
 `OS_Name` varchar(200) NOT NULL,
 `OS_Version` varchar(200) NOT NULL,
 `OS_Manufacturer` varchar(200) NOT NULL,
 `OS_Configuration` varchar(200) NOT NULL,
 `OS_Build_Type` varchar(200) NOT NULL,
 `Registered_Owner` varchar(200) NOT NULL,
 `Registered_Organization` varchar(200) NOT NULL,
 `Product_ID` varchar(200) NOT NULL,
 `Original_Install_Date` varchar(200) NOT NULL,
 `System_Boot_Time` varchar(200) NOT NULL,
 `System_Manufacturer` varchar(200) NOT NULL,
 `System_Model` varchar(200) NOT NULL,
 `System_Type` varchar(200) NOT NULL,
 `Processor` varchar(200) NOT NULL,
 `Processor_Name` varchar(200) NOT NULL,
 `BIOS_Version` varchar(200) NOT NULL,
 `Windows_Directory` varchar(200) NOT NULL,
 `System_Directory` varchar(200) NOT NULL,
 `Boot_Device` varchar(200) NOT NULL,
 `System_Locale` varchar(200) NOT NULL,
 `Input_Locale` varchar(200) NOT NULL,
 `Time_Zone` varchar(200) NOT NULL,
 `Total_Physical_Memory` varchar(200) NOT NULL,
 `Virtual_Memory_Max_Size` varchar(200) NOT NULL,
 `Virtual_Memory_Available` varchar(200) NOT NULL,
 `Virtual_Memory_In_Use` varchar(200) NOT NULL,
 `Page_File_Location` varchar(200) NOT NULL,
 `Domain` varchar(200) NOT NULL,
 `Logon_Server` varchar(200) NOT NULL,
 `Network_Card` varchar(200) NOT NULL,
 `MacIDs` varchar(200) NOT NULL,
 `Available_Physical_Memory` varchar(100) NOT NULL,
 `Date` date NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `index_system_info` (`MacIDs`,`Registered_Owner`,`Product_ID`,`Date`),
 UNIQUE KEY `Date` (`Date`),
 UNIQUE KEY `Date_2` (`Date`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1';


mysql_select_db('drdo');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create table: ' . mysql_error());
}
echo "Table employee created successfully\n";


$sql ='CREATE TABLE `headers` (
 `MacIDs` varchar(100) NOT NULL,
 `Username` varchar(20) NOT NULL,
 `Data_Type` varchar(100) NOT NULL,
 `id` int(11) NOT NULL AUTO_INCREMENT,
 PRIMARY KEY (`id`),
 UNIQUE KEY `unique_index_header` (`MacIDs`,`Username`,`Data_Type`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1';
mysql_select_db('drdo');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create table: ' . mysql_error());
}
echo "Table employee created successfully\n";


$sql ='CREATE TABLE `user` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `username` varchar(20) NOT NULL,
 `password` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1';

mysql_select_db('drdo');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not create table: ' . mysql_error());
}
echo "Table employee created successfully\n";





mysql_close($conn);
?>