<?php

class Hash{
	public static function make($string) {
		return password_hash($string, PASSWORD_DEFAULT);
	}
    
	public static function verify($string,$hash) {
		if (password_verify($string, $hash)) {
           return true;
		} else {
           return false;
        }
	}
}

?>