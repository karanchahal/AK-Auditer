<!DOCTYPE html>
<html lang="en">
<head>
	<title>Audit-Pro</title>
	<meta charset="utf-8">
	<meta name="author" content="pixelhint.com">
	<meta name="description" content="A secure state logging system"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</head>
<body>

	<header>
		<div class="logo">
			<a href="index.html"><img src="img/logo.png" title="Audit-Pro" alt="Magnetic"/></a>
		</div><!-- end logo -->

		<div id="menu_icon"></div>
		<nav>
			<ul>
			   <li><form>
				<li><a href="index.php" class="selected">Admin Panel</a></li>
				<li><a href="storage.php">Storage</a></li>
				<li><a href="systeminfo.php">System Information</a></li>
				<li><a href="alerts.php">Alerts</a></li>
				
			</ul>
		</nav><!-- end navigation menu -->

		
	</header><!-- end header -->

	<section class="main clearfix">
		<html lang="en">
<head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
  <title></title>
          
<link href="http://fonts.googleapis.com/css?family=Montserrat:300,400,700" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Muli:300,400" rel="stylesheet" type="text/css">

<!--   CSS for 147 Colors   -->
<link href="http://docs.justinav.info/cfbc.css" rel="stylesheet" type="text/css"> 
    
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

  
          
<!--    color palettes       -->
  
  
  <center style="
    height: 600px;
">
  
  <h3>Enter  Date:</h3><br>
<input type="date" name="date" value="Bike"> 
<input type="submit" value="Submit">
  </center>
  
  
  
  
  
 
  


  
  
   <?php
require_once'core/init.php';



$user = new User();

if(!$user->isLoggedIn())
{
	Redirect::to('login.php');
}

$session =new Session();
$date =Input::get('date');
if(!empty($date))
$session->put('date',$date);



$user2 = new User();



 



	   

	  
	  
	  
   
	

?>
   
   
   
   
   
   
   
  
   
  


  </div>
  
	</section><!-- end main -->
	
</body>
</html>