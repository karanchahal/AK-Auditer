// auditprodll.cpp : Defines the exported functions for the DLL application.
//

// auditprocmd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "windows.h"
#include <string>
#include "processthreadsapi.h"
#include <fstream>
#include <ctime>
#include "Iphlpapi.h"
#include "assert.h"
#include <vector>
#include <Lmcons.h>



#include "auditprodll.h"


#pragma comment(lib, "IPHLPAPI.lib")

using namespace std;

namespace AuditFuncs
{
	string string_to_hex(const string& input)
	{
		static const char* const lut = "0123456789ABCDEF";
		size_t len = input.length();

		std::string output;
		output.reserve(2 * len);
		for (size_t i = 0; i < len; ++i)
		{
			const unsigned char c = input[i];
			output.push_back(lut[c >> 4]);
			output.push_back(lut[c & 15]);
		}
		return output;
	}

	vector<string> GetAdapterInf(void)
	{
		IP_ADAPTER_INFO AdapterInfo[16];       // Allocate information 
		// for up to 16 NICs
		DWORD dwBufLen = sizeof(AdapterInfo);  // Save memory size of buffer

		DWORD dwStatus = GetAdaptersInfo(      // Call GetAdapterInfo
			AdapterInfo,                 // [out] buffer to receive data
			&dwBufLen);                  // [in] size of receive data buffer
		assert(dwStatus == ERROR_SUCCESS);  // Verify return value is 
		// valid, no buffer overflow

		PIP_ADAPTER_INFO pAdapterInfo = AdapterInfo; // Contains pointer to
		// current adapter info
		vector<string> result;
		//	vector<PIP_ADAPTER_INFO> result;
		do {
			result.push_back(reinterpret_cast< char const* >(pAdapterInfo->Address)); // Print MAC address
			//result.push_back(pAdapterInfo);
			pAdapterInfo = pAdapterInfo->Next;    // Progress through 
			// linked list
		} while (pAdapterInfo);                    // Terminate if last adapter

		return result;
	}

	const string currentDateTime() {
		time_t     now = time(0);
		struct tm  tstruct;
		char       buf[80];
		localtime_s(&tstruct, &now);
		strftime(buf, sizeof(buf), "%Y-%m-%d.%X", &tstruct);

		return buf;
	}


	void remove_space(string& line)
	{
		int a = 0, b = 0;
		unsigned int i;
		int flag2 = 1;
		for (i = 0; i < line.length(); i++)
		{

			if (i < line.length() - 2)
			if (line[i] == ' ' && line[i + 1] == ' ' && flag2 == 1)
			{
				a = i;
				flag2 = 0;
			}
			if (line[i] == ':' && flag2 == 0)
			{
				b = i;
				break;
			}
		}
		if (i != line.length() && b>a)
			line.erase(a, b - a);

	}

	void write_header(fstream& finalfile)
	{
		finalfile << "Date/Time : ";
		finalfile << currentDateTime() << "!";
		finalfile << "MacIDs : ";
		//	vector<PIP_ADAPTER_INFO> MacIds = GetAdapterInf();
		vector<string> MacIds = GetAdapterInf();
		for (unsigned int i = 0; i < MacIds.size(); i++)
		{
			//	finalfile << (int)MacIds[i][0] << "-" << (int)MacIds[i][1] << "-" << (int)MacIds[i][2] << "-" << (int)MacIds[i][3] << "-" << (int)MacIds[i][4] << "-" << (int)MacIds[i][5] << " ";
			finalfile << string_to_hex(MacIds[i]) << " ";
		}
		finalfile << "!";
		/*	finalfile << "IPS :";
		for (int i = 0; i < MacIds.size(); i++)
		{
		finalfile << " "<< MacIds[i]->IpAddressList.IpAddress.String;
		}
		finalfile << "!";*/
		TCHAR username[UNLEN + 1];
		DWORD size = UNLEN + 1;
		GetUserName(username, &size);

		finalfile << "Username : " << username << "!";
		//finalfile << "Username : " << username <<"!";

	}

	void run_process(LPCTSTR appname, LPWSTR cmdline)
	{
		STARTUPINFO si;
		PROCESS_INFORMATION pi;
		//"G:\\BITS\\PS\\usbdeview-x64\\USBDeview.exe"
		//"C:\\Windows\\System32\\notepad.exe"
		// set the size of the structures
		ZeroMemory(&si, sizeof(si));
		si.cb = sizeof(si);
		ZeroMemory(&pi, sizeof(pi));
		/*	CreateProcess(TEXT("G:\\BITS\\PS\\usbdeview-x64\\USBDeview.exe"),   // Name of program to execute
		TEXT(""),                  // Command line
		NULL,                      // Process handle not inheritable
		NULL,                      // Thread handle not inheritable
		FALSE,                     // Set handle inheritance to FALSE
		0,                         // No creation flags
		NULL,                      // Use parent's environment block
		NULL,                      // Use parent's starting directory
		&si,                       // Pointer to STARTUPINFO structure
		&pi);
		*/
		CreateProcess(appname,   // Name of program to execute
			cmdline,                  // Command line
			NULL,                      // Process handle not inheritable
			NULL,                      // Thread handle not inheritable
			FALSE,                     // Set handle inheritance to FALSE
			0,                         // No creation flags
			NULL,                      // Use parent's environment block
			NULL,                      // Use parent's starting directory
			&si,                       // Pointer to STARTUPINFO structure
			&pi);

		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);

	}
	void storage_data()
	{
		run_process(TEXT("D:\\AuditPro\\USBDeview.exe"), TEXT("D:\\AuditPro\\USBDeview.exe /stext D:\\AuditPro\\usboutput1.txt"));
		string line;

		fstream myfile, finalfile;
		myfile.open("D:\\AuditPro\\usboutput1.txt", ios::in);
		finalfile.open("D:\\AuditPro\\usboutput.txt", ios::out);
		//Page Header Code Start
		write_header(finalfile);
		finalfile << "Data Type : " << "Storage Device Data" << "^";
		//Page Header Code End

		int flag = 0;
		int checksum = 0;
		while (getline(myfile, line))
		{
			if (line[0] == '=')
			{
				if (flag == 1)
				{
					finalfile << "^";
					checksum += (int)'^';
					checksum %= 256;
					flag = 0;
				}
				else
					flag = 1;
			}
			else
			{
				remove_space(line);
				finalfile << line;
				for (unsigned int i = 0; i < line.length(); i++)
					checksum += (int)line[i];
				if (flag != 0)
				{
					if (line.substr(0, 4).compare("Capa") != 0)
					{
						finalfile << "!";
						checksum += (int)'!';
						checksum %= 256;
					}
				}
			}
		}

		finalfile << endl << (char)(checksum % 256);

		myfile.close();

		finalfile.close();

	}

	void system_info()
	{
		//run_process(TEXT("C:\\windows\\system32\\cmd.exe"), TEXT(" systeminfo>D:\\systeminfo.txt"));
		system("systeminfo>D:\\AuditPro\\systeminfo1.txt");

		string line;
		fstream myfile, finalfile;

		myfile.open("D:\\AuditPro\\systeminfo1.txt", ios::in);
		finalfile.open("D:\\AuditPro\\systeminfo.txt", ios::out);
		write_header(finalfile);
		finalfile << "Data Type : " << "System Information" << "^";

		int checksum = 0;
		int flag = 0;
		while (getline(myfile, line))
		{
			int a = 0, b = 0;
			if (line.substr(0, 4).compare("Hotf") != 0 && line.substr(0, 4).compare("    ") != 0 && line.substr(0, 4).compare("Hype") != 0)
			{
				if (line.substr(0, 4).compare("Virt") == 0)
					line.erase(14, 1);
				//			remove_space(line);
				unsigned int i = 0;
				int a = 0;
				while (i < line.length())
				{
					if (line[i] == ':' && a == 0)
						a = i + 1;

					i++;

					if (a != 0 && line[i] != ' ')
						break;
				}

				if (i != line.length())
					line.erase(a, i - a);
				if (a != 0)
					line[a - 1] = '~';
				finalfile << line;
				finalfile << "!";
			}
			if (flag == 0)
			{
				if (line.substr(0, 4).compare("Proc") == 0)
				{
					getline(myfile, line);
					int j = 0;
					while (line[j++] == ' ');

					line.erase(0, j + 5);
					finalfile << "Processor Name: ";
					finalfile << line << "!";
				}
			}
		}

		finalfile << endl << (char)(checksum % 256);

		myfile.close();

		finalfile.close();

	}


	int runner()
	{
		storage_data();
		system_info();
		return 0;
	}
}

