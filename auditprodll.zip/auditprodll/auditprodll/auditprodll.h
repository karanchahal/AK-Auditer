#include <stdexcept>
using namespace std;

namespace AuditFuncs
{
	extern "C" { __declspec(dllexport) int runner(); }
}